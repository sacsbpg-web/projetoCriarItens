package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class Projeto {

    @Autowired
    private ItemRepository repository;

    @GetMapping("/")
    public String listar(Model model) {
        model.addAttribute("itens", repository.findAll());
        model.addAttribute("itemForm", new Item());
        return "projeto";
    }

    @PostMapping("/salvar")
    public String salvar(@ModelAttribute Item item) {
        if (item.getId() != null) {
            repository.findById(item.getId()).ifPresent(existente ->
                    item.setDataAdicao(existente.getDataAdicao())
            );
        }
        repository.save(item);
        return "redirect:/";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Item item = repository.findById(id).orElse(new Item());
        model.addAttribute("itens", repository.findAll());
        model.addAttribute("itemForm", item);
        return "projeto";
    }

    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id) {
        repository.deleteById(id);
        return "redirect:/";
    }
}
